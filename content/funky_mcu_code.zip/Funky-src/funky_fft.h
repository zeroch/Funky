#include <stdio.h>
#include <stdarg.h>

// Extracted from Numerical Recipes in C
void vFFT(double data[], unsigned int nn);
// Extracted from Numerical Recipes in C
void vRealFFT(double data[], unsigned int n);

void vCalPowerf(double Input[],double Power[], unsigned int n);

void vCalPowerInt(double Input[],unsigned char Power[], unsigned int n);

void vCalPowerLog(double Input[],unsigned char Power[], unsigned int n);

double indexToFreq(int i,double sample_rate,int nFFT);

int findMax(unsigned char *array,int length);

#define PI 3.14159265
// unsigned int SAMPLE_SIZE = 256;
