
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ble_app_hrs_s110_pca10028' 
 * Target:  'nrf51422_xxac_s110' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define BLE_STACK_SUPPORT_REQD
  #define S110
#define SOFTDEVICE_PRESENT

#endif /* RTE_COMPONENTS_H */
