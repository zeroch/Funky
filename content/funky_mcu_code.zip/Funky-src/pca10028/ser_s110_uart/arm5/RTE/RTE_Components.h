
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ble_app_hrs_s110_uart_pca10028' 
 * Target:  'nrf51422_xxac_s110' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define SVCALL_AS_NORMAL_FUNCTION
  #define BLE_STACK_SUPPORT_REQD
  #define S110

#endif /* RTE_COMPONENTS_H */
