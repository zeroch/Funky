/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */
/** @example examples/ble_peripheral/ble_app_hrs/main.c
 *
 * @brief Heart Rate Service Sample Application main file.
 *
 * This file contains the source code for a sample application using the Heart Rate service
 * (and also Battery and Device Information services). This application uses the
 * @ref srvlib_conn_params module.
 */

#include <stdint.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf.h"
#include "app_error.h"
#include "nrf51_bitfields.h"
#include "ble.h"
#include "ble_hci.h"
#include "ble_srv_common.h"
#include "ble_advdata.h"
#include "ble_bas.h"
#include "ble_hrs.h"
#include "ble_dis.h"
#ifdef BLE_DFU_APP_SUPPORT
#include "ble_dfu.h"
#include "dfu_app_handler.h"
#endif // BLE_DFU_APP_SUPPORT
#include "ble_conn_params.h"
#include "boards.h"
#include "ble_sensorsim.h"
#include "softdevice_handler.h"
#include "app_timer.h"
#include "device_manager.h"
#include "pstorage.h"
#include "app_trace.h"
#include "app_gpiote.h"
#include "bsp.h"

#include <stdio.h>
#include <stdarg.h>
#include "simple_uart.h"
#include "app_uart.h"
#include "app_button.h"
#include "nrf_adc.h"
#include "nrf_delay.h"
#include "nrf_soc.h"
// #include "funky_fft.h"

#define IS_SRVC_CHANGED_CHARACT_PRESENT     0                                           /**< Include or not the service_changed characteristic. if not enabled, the server's database cannot be changed for the lifetime of the device*/

#define WAKEUP_BUTTON_ID                     0                                          /**< Button used to wake up the application. */
#define BOND_DELETE_ALL_BUTTON_ID            1                                          /**< Button used for deleting all bonded centrals during startup. */

#define DEVICE_NAME                          "Funky"                               /**< Name of device. Will be included in the advertising data. */
#define MANUFACTURER_NAME                    "Gatech"                      /**< Manufacturer. Will be passed to Device Information Service. */
#define APP_ADV_INTERVAL                     40                                         /**< The advertising interval (in units of 0.625 ms. This value corresponds to 25 ms). */
#define APP_ADV_TIMEOUT_IN_SECONDS           180                                        /**< The advertising timeout in units of seconds. */

#define APP_TIMER_PRESCALER                  0                                          /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_MAX_TIMERS                 (6+BSP_APP_TIMERS_NUMBER)                  /**< Maximum number of simultaneously created timers. */
#define APP_TIMER_OP_QUEUE_SIZE              4                                          /**< Size of timer operation queues. */

#define BATTERY_LEVEL_MEAS_INTERVAL          APP_TIMER_TICKS(2000, APP_TIMER_PRESCALER) /**< Battery level measurement interval (ticks). */
#define MIN_BATTERY_LEVEL                    81                                         /**< Minimum simulated battery level. */
#define MAX_BATTERY_LEVEL                    100                                        /**< Maximum simulated battery level. */
#define BATTERY_LEVEL_INCREMENT              1                                          /**< Increment between each simulated battery level measurement. */

#define HEART_RATE_MEAS_INTERVAL             APP_TIMER_TICKS(2000, APP_TIMER_PRESCALER) /**< Heart rate measurement interval (ticks). */
#define MIN_HEART_RATE                       140                                        /**< Minimum heart rate as returned by the simulated measurement function. */
#define MAX_HEART_RATE                       300                                        /**< Maximum heart rate as returned by the simulated measurement function. */
#define HEART_RATE_INCREMENT                 10                                         /**< Value by which the heart rate is incremented/decremented for each call to the simulated measurement function. */

#define RR_INTERVAL_INTERVAL                 APP_TIMER_TICKS(300, APP_TIMER_PRESCALER)  /**< RR interval interval (ticks). */
#define MIN_RR_INTERVAL                      100                                        /**< Minimum RR interval as returned by the simulated measurement function. */
#define MAX_RR_INTERVAL                      500                                        /**< Maximum RR interval as returned by the simulated measurement function. */
#define RR_INTERVAL_INCREMENT                1                                          /**< Value by which the RR interval is incremented/decremented for each call to the simulated measurement function. */

#define SENSOR_CONTACT_DETECTED_INTERVAL     APP_TIMER_TICKS(5000, APP_TIMER_PRESCALER) /**< Sensor Contact Detected toggle interval (ticks). */

#define MIN_CONN_INTERVAL                    MSEC_TO_UNITS(500, UNIT_1_25_MS)           /**< Minimum acceptable connection interval (0.5 seconds). */
#define MAX_CONN_INTERVAL                    MSEC_TO_UNITS(1000, UNIT_1_25_MS)          /**< Maximum acceptable connection interval (1 second). */
#define SLAVE_LATENCY                        0                                          /**< Slave latency. */
#define CONN_SUP_TIMEOUT                     MSEC_TO_UNITS(4000, UNIT_10_MS)            /**< Connection supervisory timeout (4 seconds). */

#define FIRST_CONN_PARAMS_UPDATE_DELAY       APP_TIMER_TICKS(5000, APP_TIMER_PRESCALER) /**< Time from initiating event (connect or start of notification) to first time sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY        APP_TIMER_TICKS(30000, APP_TIMER_PRESCALER)/**< Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT         3                                          /**< Number of attempts before giving up the connection parameter negotiation. */

#define SEC_PARAM_TIMEOUT                    30                                         /**< Timeout for Pairing Request or Security Request (in seconds). */
#define SEC_PARAM_BOND                       1                                          /**< Perform bonding. */
#define SEC_PARAM_MITM                       0                                          /**< Man In The Middle protection not required. */
#define SEC_PARAM_IO_CAPABILITIES            BLE_GAP_IO_CAPS_NONE                       /**< No I/O capabilities. */
#define SEC_PARAM_OOB                        0                                          /**< Out Of Band data not available. */
#define SEC_PARAM_MIN_KEY_SIZE               7                                          /**< Minimum encryption key size. */
#define SEC_PARAM_MAX_KEY_SIZE               16                                         /**< Maximum encryption key size. */

#define DEAD_BEEF                            0xDEADBEEF                                 /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */
#ifdef BLE_DFU_APP_SUPPORT
#define DFU_REV_MAJOR                        0x00                                       /** DFU Major revision number to be exposed. */
#define DFU_REV_MINOR                        0x01                                       /** DFU Minor revision number to be exposed. */
#define DFU_REVISION                         ((DFU_REV_MAJOR << 8) | DFU_REV_MINOR)     /** DFU Revision number to be exposed. Combined of major and minor versions. */
#endif // BLE_DFU_APP_SUPPORT


// For Uart debug testing. 
// replace with simple_uart and app_uart.h
#define DEBUG 0
#define DEBUG_2 0
static int rtc_count = 0;
#define UART_TX_BUF_SIZE 256
#define UART_RX_BUF_SIZE 1

#define MAX_TEST_DATA_BYTES 	(15U)
#define BUTTON_DEBOUNCE_DELAY               APP_TIMER_TICKS(50, APP_TIMER_PRESCALER)  // delay from a GPIOTE event until a button is reported as pushed. 
#define APP_GPIOTE_MAX_USERS                1   // max number of user of gpio handler  one for original, 2 for buttons. 

#define ADC_SAMPLING_INTERVAL               APP_TIMER_TICKS(100, APP_TIMER_PRESCALER)

#define FUNKY_ADC_CONFIG_DEFAULT { NRF_ADC_CONFIG_RES_10BIT,               \
                                 NRF_ADC_CONFIG_SCALING_INPUT_ONE_THIRD, \
                                 NRF_ADC_CONFIG_REF_VBG }

static void application_timers_start(void);


static uint16_t                              m_conn_handle = BLE_CONN_HANDLE_INVALID;   /**< Handle of the current connection. */
static ble_gap_adv_params_t                  m_adv_params;                              /**< Parameters to be passed to the stack when starting advertising. */
static ble_bas_t                             m_bas;                                     /**< Structure used to identify the battery service. */
static ble_hrs_t                             m_hrs;                                     /**< Structure used to identify the heart rate service. */
static bool                                  m_rr_interval_enabled = true;              /**< Flag for enabling and disabling the registration of new RR interval measurements (the purpose of disabling this is just to test sending HRM without RR interval data. */

static ble_sensorsim_cfg_t                   m_battery_sim_cfg;                         /**< Battery Level sensor simulator configuration. */
static ble_sensorsim_state_t                 m_battery_sim_state;                       /**< Battery Level sensor simulator state. */
static ble_sensorsim_cfg_t                   m_heart_rate_sim_cfg;                      /**< Heart Rate sensor simulator configuration. */
static ble_sensorsim_state_t                 m_heart_rate_sim_state;                    /**< Heart Rate sensor simulator state. */
static ble_sensorsim_cfg_t                   m_rr_interval_sim_cfg;                     /**< RR Interval sensor simulator configuration. */
static ble_sensorsim_state_t                 m_rr_interval_sim_state;                   /**< RR Interval sensor simulator state. */

static app_timer_id_t                        m_battery_timer_id;                        /**< Battery timer. */
static app_timer_id_t                        m_heart_rate_timer_id;                     /**< Heart rate measurement timer. */
static app_timer_id_t                        m_rr_interval_timer_id;                    /**< RR interval timer. */
static app_timer_id_t                        m_sensor_contact_timer_id;                 /**< Sensor contact detected timer. */

static app_timer_id_t                        m_adc_timer_id;                 /**< TESTING ADC timer timer. */


static dm_application_instance_t             m_app_handle;                              /**< Application identifier allocated by device manager */

static bool                                  m_memory_access_in_progress = false;       /**< Flag to keep track of ongoing operations on persistent memory. */
#ifdef BLE_DFU_APP_SUPPORT    
static ble_dfu_t                             m_dfus;                                    /**< Structure used to identify the DFU service. */
#endif // BLE_DFU_APP_SUPPORT    

#ifndef NRF_APP_PRIORITY_HIGH
#define NRF_APP_PRIORITY_HIGH 1
#endif
#ifndef NRF_APP_PRIORITY_LOW
#define NRF_APP_PRIORITY_LOW 3
#endif

#define number_of_ms 50
// call back for the uart testing. 
static uint8_t adc_sample;
static uint8_t pre_adc_sample;
#define DELTA 0.05
#define DELTA_PERIOD 0.1
static bool adc_maxFound = false;
static int running_count = 0;
static int count1 = -1;
static int count2 = -1;
static double max1 = 0.0;
static double max2 = 0.0;
static double global_max = 0.0;
static bool firstRun = true;
static double difference = 0.05;
static double data = 0;
#define SIZE  128
static double data_buf[SIZE];

typedef enum { DATA, COMPUTE, FFT,  IDLE} state_t;
static state_t m_state = IDLE;

/* FIXME HARD CODE THE HEART RATE */
typedef enum {
    CHILD   = 105,
    YOUNG   = 70,
    OLD     = 65
} heart_rate_mode_t;


static heart_rate_mode_t heart_rate_preset = YOUNG;

typedef enum {
    A   = 200,
    B   = 100,
    C   = 50
} spo_mode_t;

spo_mode_t battery_level_preset = A;

static uint16_t spo_invisible   = 0;
static uint16_t spo_visible     = 0;


void vFFT(double data[], unsigned int nn);
// Extracted from Numerical Recipes in C
void vRealFFT(double data[], unsigned int n);
void vCalPowerf(double Input[],double Power[], unsigned int n);
void vCalPowerInt(double Input[],unsigned char Power[], unsigned int n);
void vCalPowerLog(double Input[],unsigned char Power[], unsigned int n);
double indexToFreq(int i,double sample_rate,int nFFT);
int findMax(unsigned char *array,int length);
void swap(double *a, double *b);

#define PI 3.14159265


// static double pre_data = 0;

void uart_events_handler(app_uart_evt_t * p_event)
{
    switch (p_event->evt_type)
    {
        case APP_UART_COMMUNICATION_ERROR: APP_ERROR_HANDLER(p_event->data.error_communication);
            break;

        case APP_UART_FIFO_ERROR:          APP_ERROR_HANDLER(p_event->data.error_code);
            break;

        // case APP_UART_TX_EMPTY:            printf("%d\r\n", (int)adc_sample); // out ADC result
        //     break;

        default: break;
    }
}

void uart_config(void)
{
    uint32_t err_code;
    const app_uart_comm_params_t comm_params =
    {
        RX_PIN_NUMBER,
        TX_PIN_NUMBER,
        RTS_PIN_NUMBER,
        CTS_PIN_NUMBER,
        APP_UART_FLOW_CONTROL_DISABLED,
        false,
        UART_BAUDRATE_BAUDRATE_Baud38400
    };

    APP_UART_FIFO_INIT(&comm_params,
                        UART_RX_BUF_SIZE,
                        UART_TX_BUF_SIZE,
                        uart_events_handler,
                        APP_IRQ_PRIORITY_LOW,
                        err_code);

    APP_ERROR_CHECK(err_code);
}

static __INLINE void uart_start()
{
    printf(" \n\rStart: ");
}


static __INLINE void uart_quit()
{
	printf("\n\rExit!\n\r");
}



static void debug_msg(const char *format, ...)
{

    char buffer[249];
    char fmsg[256] = "\n\rDebug: ";
    va_list args;
    va_start(args, format);
    vsprintf(buffer, format, args);
    va_end(args);
    strcat(fmsg, buffer);
    strcat(fmsg, "\n\r");

    printf(fmsg);
}

static void dark_force()
{
       debug_msg("This is dark force");
        // app_timer_stop_all();
        // for (int i = 0; i < SIZE; ++i){
        //     debug_msg("Dark Force, do something nasty: %d,  %f", i, data_buf[i]);
        //     // this wait is allow uart to process the io interrupt. 
        //     nrf_delay_ms(20);
        // }
 
        nrf_delay_ms(50);

        unsigned char PowerInt[SIZE/2];
        double sample = 0.05;
        double sample_rate = 1/sample;
        // nrf_delay_ms(2000);
        debug_msg("_______________FFT Start________");
         nrf_delay_ms(50);

        debug_msg("before FFT done\n");
        nrf_delay_ms(50);
                // debug_msg("before FFT done ---    \n");
                
        vFFT(data_buf-1,SIZE);
        nrf_delay_ms(2000);
           //     debug_msg("FFT done\n");

        vCalPowerInt(data_buf,PowerInt,SIZE/2);
        debug_msg("FFT mag done ----\n");
        nrf_delay_ms(20);
        int max = findMax(PowerInt, SIZE/2);
                    nrf_delay_ms(20);
        debug_msg("Find MAX done");
        nrf_delay_ms(2000);
        double freq = indexToFreq(max, sample_rate, SIZE);
        nrf_delay_ms(20);
        debug_msg("PERIOD = %f\n",1/freq);
        double BPM = freq * 60.0; 
        nrf_delay_ms(20);
        debug_msg("BPM = %f\n",BPM);


}

static void timer_start(void )
{
    // Start 16 MHz crystal oscillator.
    // NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;
    // NRF_CLOCK->TASKS_HFCLKSTART    = 1;

    // Wait for the external oscillator to start up.
    // while (NRF_CLOCK->EVENTS_HFCLKSTARTED == 0)
    // {
    //     // Do nothing.
    // }
	  NRF_TIMER2->TASKS_CLEAR =1;
    NRF_TIMER2->MODE        = TIMER_MODE_MODE_Timer;       // Set the timer in Timer Mode.
    // NRF_TIMER2->PRESCALER   = 9;                           // Prescaler 9 produces 31250 Hz timer frequency => 1 tick = 32 us.
    // NRF_TIMER2->BITMODE     = TIMER_BITMODE_BITMODE_16Bit; // 16 bit mode.
    // // With 32 us ticks, we need to multiply by 31.25 to get milliseconds.
    NRF_TIMER2->PRESCALER = 9;
    NRF_TIMER2->BITMODE = TIMER_BITMODE_BITMODE_16Bit;
    NRF_TIMER2->CC[0]       = number_of_ms * 31;
    NRF_TIMER2->CC[0]      += number_of_ms / 4;
    // NRF_TIMER2->CC[0] = 1000 * 500;
    //NRF_TIMER2->CC[1] = 5;

// Enable interrupt on Timer 2, both for CC[0] and CC[1] compare match events
    NRF_TIMER2->INTENSET = (TIMER_INTENSET_COMPARE0_Enabled << TIMER_INTENSET_COMPARE0_Pos)   | (TIMER_INTENSET_COMPARE1_Enabled << TIMER_INTENSET_COMPARE1_Pos);
    NVIC_EnableIRQ(TIMER2_IRQn);
    NVIC_SetPriority(TIMER2_IRQn, NRF_APP_PRIORITY_HIGH);
    // NRF_TIMER2->TASKS_START = 1;
}




void TIMER2_IRQHandler()
{
        // debug_msg("TIMER2 Handler");
    if (NRF_TIMER2->EVENTS_COMPARE[0] != 0 && ((NRF_TIMER2->INTENSET & TIMER_INTENSET_COMPARE0_Msk) != 0))
    {
        // uint8_t RTC_sample = nrf_adc_convert_single(NRF_ADC_CONFIG_INPUT_2);
        // double rtc_data =  ((double)RTC_sample / 255 )*3.6;
        // debug_msg("TIMER2 data: %f", rtc_data);
        // debug_msg("TIMER2 Handler ADC");
        nrf_adc_start();
        rtc_count++;
        if (rtc_count*2 == 256)
        {
            NRF_TIMER2->TASKS_CLEAR = 1;
            NRF_TIMER2->TASKS_STOP = 1;
            rtc_count = 0;
            // dark_force();
            m_state = COMPUTE;
        }
        NRF_TIMER2->EVENTS_COMPARE[0] = 0;
        // NRF_TIMER2->TASKS_CLEAR = 1;
        // NRF_TIMER2->CC[0] += 50*1000;
    }else 
    {
        // debug_msg("TIMER2 Handler NOT ADC");

    }
            // NRF_TIMER2->TASKS_STOP = 1;
            NRF_TIMER2->TASKS_CLEAR = 1;

}


#define LFCLK_FREQUENCY           (32768UL)                                 /**< LFCLK frequency in Hertz, constant. */
#define RTC_FREQUENCY             (8UL)                                     /**< Required RTC working clock RTC_FREQUENCY Hertz. Changable. */
#define COMPARE_COUNTERTIME       (3UL)                                     /**< Get Compare event COMPARE_TIME seconds after the counter starts from 0. */
#define COUNTER_PRESCALER         ((LFCLK_FREQUENCY / RTC_FREQUENCY) - 1)   /* f = LFCLK/(prescaler + 1) */



/** @brief Function starting the internal LFCLK XTAL oscillator.
 */
static void lfclk_config(void)
{
	 // uint32_t err_code;
     // error_code = sd_softdevice_enable(NRF_CLOCK_LFCLKSRC_XTAL_20_PPM)
    // NRF_CLOCK->LFCLKSRC            = (CLOCK_LFCLKSRC_SRC_Xtal << CLOCK_LFCLKSRC_SRC_Pos);
    NRF_CLOCK->EVENTS_LFCLKSTARTED = 0;
    NRF_CLOCK->TASKS_LFCLKSTART    = 1;

    while (NRF_CLOCK->EVENTS_LFCLKSTARTED == 0)
    {
        // Do nothing.
    }
    NRF_CLOCK->EVENTS_LFCLKSTARTED = 0;
}


void spo1()
{
        // interrupt ADC
    NRF_ADC->INTENSET = (ADC_INTENSET_END_Disabled << ADC_INTENSET_END_Pos);                        /*!< Interrupt enabled. */
                    
    // config ADC
    NRF_ADC->CONFIG = (ADC_CONFIG_EXTREFSEL_None << ADC_CONFIG_EXTREFSEL_Pos) /* Bits 17..16 : ADC external reference pin selection. */
                                        | (ADC_CONFIG_PSEL_AnalogInput5 << ADC_CONFIG_PSEL_Pos)                 /*!< Use analog input 0 as analog input. */
                                        | (ADC_CONFIG_REFSEL_VBG << ADC_CONFIG_REFSEL_Pos)                          /*!< Use internal 1.2V bandgap voltage as reference for conversion. */
                                        | (ADC_CONFIG_INPSEL_AnalogInputOneThirdPrescaling << ADC_CONFIG_INPSEL_Pos) /*!< Analog input specified by PSEL with no prescaling used as input for the conversion. */
                                        | (ADC_CONFIG_RES_10bit << ADC_CONFIG_RES_Pos);                                 /*!< 10bit ADC resolution. */ 
    
    // enable ADC       
    NRF_ADC->ENABLE = ADC_ENABLE_ENABLE_Enabled;                                                                        /* Bit 0 : ADC enable. */       
    
    // start ADC conversion
    NRF_ADC->TASKS_START = 1;
    
    // wait for conversion to end
    while (!NRF_ADC->EVENTS_END)
    {}
    NRF_ADC->EVENTS_END = 0;
    
    //Save your ADC result
    spo_visible = NRF_ADC->RESULT;   
        
    //Use the STOP task to save current. Workaround for PAN_028 rev1.1 anomaly 1.
  NRF_ADC->TASKS_STOP = 1;

}

void spo2()
{
        // interrupt ADC
    NRF_ADC->INTENSET = (ADC_INTENSET_END_Disabled << ADC_INTENSET_END_Pos);                        /*!< Interrupt enabled. */
                    
    // config ADC
    NRF_ADC->CONFIG = (ADC_CONFIG_EXTREFSEL_None << ADC_CONFIG_EXTREFSEL_Pos) /* Bits 17..16 : ADC external reference pin selection. */
                                        | (ADC_CONFIG_PSEL_AnalogInput6 << ADC_CONFIG_PSEL_Pos)                 /*!< Use analog input 0 as analog input. */
                                        | (ADC_CONFIG_REFSEL_VBG << ADC_CONFIG_REFSEL_Pos)                          /*!< Use internal 1.2V bandgap voltage as reference for conversion. */
                                        | (ADC_CONFIG_INPSEL_AnalogInputOneThirdPrescaling << ADC_CONFIG_INPSEL_Pos) /*!< Analog input specified by PSEL with no prescaling used as input for the conversion. */
                                        | (ADC_CONFIG_RES_10bit << ADC_CONFIG_RES_Pos);                                 /*!< 10bit ADC resolution. */ 
    
    // enable ADC       
    NRF_ADC->ENABLE = ADC_ENABLE_ENABLE_Enabled;                                                                        /* Bit 0 : ADC enable. */       
    
    // start ADC conversion
    NRF_ADC->TASKS_START = 1;
    
    // wait for conversion to end
    while (!NRF_ADC->EVENTS_END)
    {}
    NRF_ADC->EVENTS_END = 0;
    
    //Save your ADC result
    spo_invisible = NRF_ADC->RESULT;   
        
    //Use the STOP task to save current. Workaround for PAN_028 rev1.1 anomaly 1.
  NRF_ADC->TASKS_STOP = 1;

}

void compute_spo2()
{

    double spo2_val = log10(spo_visible)/log10(spo_invisible) ;
    spo2_val = spo2_val * (90.0/75.0);
    uint8_t battery_level = spo2_val * 100;
    uint32_t err_code = ble_bas_battery_level_update(&m_bas, battery_level);
    debug_msg("Battery sent data is  %d", battery_level);


    if ((err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_BUFFERS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)
        )
    {
        APP_ERROR_HANDLER(err_code);
    }

}


// ADC interrupt handler

void ADC_IRQHandler(void)
{
    nrf_adc_conversion_event_clean();

    // pre_adc_sample = adc_sample;
    double pre_data = data;
    adc_sample = nrf_adc_result_get();
    /* NRF_ADC_CONFIG_DEFAULT IS USING VB 1.2V Reference, 
                                          1/3 Scaling
                                         then, AIN Reading 3.6V
                                        10 bits max is 1023.
                                        reading/1023 * 3.6 is voltage reading. 
    */
    nrf_adc_stop();

    data = ((double)adc_sample / 255 )*heart_rate_preset;
    data_buf[rtc_count * 2] = data;
    data_buf[rtc_count * 2 + 1] = 0.0;
    // NRF_TIMER2->TASKS_START = 1;
    #if DEBUG_2
    // debug_msg("HACK: PRE ADC value is %f", pre_data);
    debug_msg("HACK: ADC value is %d,  %f", rtc_count*2, data);
    #endif

}

void adc_config(void)
{
    const nrf_adc_config_t nrf_adc_config = FUNKY_ADC_CONFIG_DEFAULT;

    // Initialize and configure ADC
    nrf_adc_configure( (nrf_adc_config_t *)&nrf_adc_config);
    nrf_adc_input_select(NRF_ADC_CONFIG_INPUT_2);
    nrf_adc_int_enable(ADC_INTENSET_END_Enabled << ADC_INTENSET_END_Pos);
    // sd_nvic_EnableIRQ(ADC_IRQn);
    // sd_nvic_SetPriority(ADC_IRQn, NRF_APP_PRIORITY_HIGH);
    NVIC_EnableIRQ(ADC_IRQn);
    NVIC_SetPriority(ADC_IRQn, NRF_APP_PRIORITY_LOW);
}

static void adc_sampling_timeout_handler(void * p_context)
{
    UNUSED_PARAMETER(p_context);
    // for (int i = 0; i < 100; i++)
        nrf_adc_start();
}

/*
 * Handler to be called when button is pushed.
 * param[in]   pin_no           The pin number where the event is genereated
 * param[in]   button_action    Is the button pushed or released
 */
static void button_handler(uint8_t pin_no, uint8_t button_action)
{
    uint32_t        err_code;
    uint16_t        heart_rate;


    debug_msg("Button %d is triggered", pin_no);
    if(button_action == APP_BUTTON_PUSH)
    {
        switch(pin_no)
        {
            case BUTTON_1:
                nrf_gpio_pin_toggle(LED_1);
                app_timer_stop_all();
                // NRF_TIMER2->TASKS_STOP = 1;
                m_state = IDLE;
                break;
            case BUTTON_2:
                nrf_gpio_pin_toggle(LED_2);
                // heart_rate = 15;
                // NRF_TIMER2->TASKS_START = 1;
                m_state = DATA;
                heart_rate_preset = CHILD;
                battery_level_preset = A;
                application_timers_start();
                break;
            case BUTTON_3:
                nrf_gpio_pin_toggle(LED_3);
                // heart_rate = 25;
                m_state = DATA;
                heart_rate_preset = YOUNG;
                battery_level_preset = B;
                application_timers_start();
                // NRF_TIMER2->TASKS_START = 1;
                break;
            case BUTTON_4:
                nrf_gpio_pin_toggle(LED_4);
                m_state = DATA;
                heart_rate_preset = OLD;
                battery_level_preset = C;
                application_timers_start();
                /* spo2 calculate */

                // spo1();
                // spo2();
                // compute_spo2();

                break;
            default:
                heart_rate = 255;
                break;
        }
    }

    debug_msg("Heart rate preset data is sent data is  %d", heart_rate_preset);
    err_code = ble_hrs_heart_rate_measurement_send(&m_hrs, heart_rate_preset);
    if ((err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_BUFFERS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)
        )
    {
        debug_msg("Fail to send heart rate data");
        APP_ERROR_HANDLER(err_code);
    }



}


 
/* bUTTON INIT
*/
void init_button()
{

    uint32_t err_code;
 // Initializing the buttons.
    static app_button_cfg_t p_button[] = 
    { 
        {BUTTON_1, APP_BUTTON_ACTIVE_LOW, NRF_GPIO_PIN_PULLUP, (app_button_handler_t)button_handler},
        {BUTTON_2, APP_BUTTON_ACTIVE_LOW, NRF_GPIO_PIN_PULLUP, (app_button_handler_t)button_handler},
        {BUTTON_3, APP_BUTTON_ACTIVE_LOW, NRF_GPIO_PIN_PULLUP, (app_button_handler_t)button_handler},
        {BUTTON_4, APP_BUTTON_ACTIVE_LOW, NRF_GPIO_PIN_PULLUP, (app_button_handler_t)button_handler}
    };
		debug_msg("Define buttons");
    err_code = app_button_init(p_button, sizeof(p_button) / sizeof(p_button[0]), BUTTON_DEBOUNCE_DELAY, NULL);
    if (err_code != NRF_SUCCESS)
    {
        APP_ERROR_CHECK(err_code);
        debug_msg("Fail to initialized");
    }
     debug_msg("first err_code check ");                                       
    // Enabling the buttons.                                        
    err_code = app_button_enable();
    if (err_code != NRF_SUCCESS)
    {
        APP_ERROR_CHECK(err_code);
        debug_msg("Fail to enable");
    }
		debug_msg("Enabling the buttons. ");
    debug_msg("Initialize buttons");
}


/**
 * Initialize all four LEDs on the nRF51 DK.
 */
void init_leds()
{
    nrf_gpio_cfg_output(LED_1);
    nrf_gpio_cfg_output(LED_2);
    nrf_gpio_cfg_output(LED_3);
    nrf_gpio_cfg_output(LED_4);
    nrf_gpio_pin_set(LED_1);
    nrf_gpio_pin_set(LED_2);
    nrf_gpio_pin_set(LED_3);
    nrf_gpio_pin_set(LED_4);
    debug_msg("initialized LEDs");
}   


/**@brief Callback function for asserts in the SoftDevice.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyze
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in]   line_num   Line number of the failing ASSERT call.
 * @param[in]   file_name  File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}


/**@brief Function for performing battery measurement and updating the Battery Level characteristic
 *        in Battery Service.
 */

 /* FIXME use battery_level_to display the SPO value */

static void battery_level_update(void)
{
    uint32_t err_code;
    uint8_t  battery_level;

    battery_level = (uint8_t)ble_sensorsim_measure(&m_battery_sim_state, &m_battery_sim_cfg);

    // FIXME replace the heart_rate_preset into spo value. 
    cnt++;
    err_code = ble_hrs_heart_rate_measurement_send(&m_hrs, data_send);
    err_code = ble_bas_battery_level_update(&m_bas, battery_level);
    debug_msg("Battery sent data is  %d", battery_level);


    if ((err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_BUFFERS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)
        )
    {
        APP_ERROR_HANDLER(err_code);
    }
}


/**@brief Function for handling the Battery measurement timer timeout.
 *
 * @details This function will be called each time the battery level measurement timer expires.
 *
 * @param[in]   p_context   Pointer used for passing some arbitrary information (context) from the
 *                          app_start_timer() call to the timeout handler.
 */
static void battery_level_meas_timeout_handler(void * p_context)
{
    UNUSED_PARAMETER(p_context);
    battery_level_update();
}


/**@brief Function for handling the Heart rate measurement timer timeout.
 *
 * @details This function will be called each time the heart rate measurement timer expires.
 *          It will exclude RR Interval data from every third measurement.
 *
 * @param[in]   p_context   Pointer used for passing some arbitrary information (context) from the
 *                          app_start_timer() call to the timeout handler.
 */
static void heart_rate_meas_timeout_handler(void * p_context)
{
    static uint32_t cnt = 0;
    uint32_t        err_code;
    uint8_t        heart_rate;

    UNUSED_PARAMETER(p_context);
    heart_rate = (uint16_t)ble_sensorsim_measure(&m_heart_rate_sim_state, &m_heart_rate_sim_cfg);
    debug_msg("Heart rate sent data is  %d", heart_rate);
	heart_rate = heart_rate_preset + r;
    cnt++;
    err_code = ble_hrs_heart_rate_measurement_send(&m_hrs, heart_rate);
    if ((err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_BUFFERS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)
        )
    {
        APP_ERROR_HANDLER(err_code);
    }
    debug_msg("Heart rate sent data is  %d", heart_rate);

    // Disable RR Interval recording every third heart rate measurement.
    // NOTE: An application will normally not do this. It is done here just for testing generation
    //       of messages without RR Interval measurements.
    m_rr_interval_enabled = ((cnt % 3) != 0);
}


/**@brief Function for handling the RR interval timer timeout.
 *
 * @details This function will be called each time the RR interval timer expires.
 *
 * @param[in]   p_context   Pointer used for passing some arbitrary information (context) from the
 *                          app_start_timer() call to the timeout handler.
 */
static void rr_interval_timeout_handler(void * p_context)
{
    UNUSED_PARAMETER(p_context);

    if (m_rr_interval_enabled)
    {
        uint16_t rr_interval;

        rr_interval = (uint16_t)ble_sensorsim_measure(&m_rr_interval_sim_state,
                                                      &m_rr_interval_sim_cfg);
        ble_hrs_rr_interval_add(&m_hrs, rr_interval);
    }
}


/**@brief Function for handling the Sensor Contact Detected timer timeout.
 *
 * @details This function will be called each time the Sensor Contact Detected timer expires.
 *
 * @param[in]   p_context   Pointer used for passing some arbitrary information (context) from the
 *                          app_start_timer() call to the timeout handler.
 */
static void sensor_contact_detected_timeout_handler(void * p_context)
{
    static bool sensor_contact_detected = false;

    UNUSED_PARAMETER(p_context);

    sensor_contact_detected = !sensor_contact_detected;
    ble_hrs_sensor_contact_detected_update(&m_hrs, sensor_contact_detected);
}


/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module. This creates and starts application timers.
 */
static void timers_init(void)
{
    uint32_t err_code;

    // Initialize timer module.
    APP_TIMER_INIT(APP_TIMER_PRESCALER, APP_TIMER_MAX_TIMERS, APP_TIMER_OP_QUEUE_SIZE, false);

    // Create timers.
    err_code = app_timer_create(&m_battery_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                battery_level_meas_timeout_handler);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_heart_rate_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                heart_rate_meas_timeout_handler);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_rr_interval_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                rr_interval_timeout_handler);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_sensor_contact_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                sensor_contact_detected_timeout_handler);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_adc_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                adc_sampling_timeout_handler);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for the GAP initialization.
 *
 * @details This function sets up all the necessary GAP (Generic Access Profile) parameters of the
 *          device including the device name, appearance, and the preferred connection parameters.
 */
static void gap_params_init(void)
{
    uint32_t                err_code;
    ble_gap_conn_params_t   gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

    err_code = sd_ble_gap_device_name_set(&sec_mode,
                                          (const uint8_t *)DEVICE_NAME,
                                          strlen(DEVICE_NAME));
    APP_ERROR_CHECK(err_code);

    err_code = sd_ble_gap_appearance_set(BLE_APPEARANCE_HEART_RATE_SENSOR_HEART_RATE_BELT);
    APP_ERROR_CHECK(err_code);

    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for initializing the Advertising functionality.
 *
 * @details Encodes the required advertising data and passes it to the stack.
 *          Also builds a structure to be passed to the stack when starting advertising.
 */
static void advertising_init(void)
{
    uint32_t      err_code;
    ble_advdata_t advdata;
    uint8_t       flags = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;

    ble_uuid_t adv_uuids[] =
    {
        {BLE_UUID_HEART_RATE_SERVICE,         BLE_UUID_TYPE_BLE},
        {BLE_UUID_BATTERY_SERVICE,            BLE_UUID_TYPE_BLE},
        {BLE_UUID_DEVICE_INFORMATION_SERVICE, BLE_UUID_TYPE_BLE}
    };

    // Build and set advertising data.
    memset(&advdata, 0, sizeof(advdata));

    advdata.name_type               = BLE_ADVDATA_FULL_NAME;
    advdata.include_appearance      = true;
    advdata.flags.size              = sizeof(flags);
    advdata.flags.p_data            = &flags;
    advdata.uuids_complete.uuid_cnt = sizeof(adv_uuids) / sizeof(adv_uuids[0]);
    advdata.uuids_complete.p_uuids  = adv_uuids;

    err_code = ble_advdata_set(&advdata, NULL);
    APP_ERROR_CHECK(err_code);

    // Initialize advertising parameters (used when starting advertising).
    memset(&m_adv_params, 0, sizeof(m_adv_params));

    m_adv_params.type        = BLE_GAP_ADV_TYPE_ADV_IND;
    m_adv_params.p_peer_addr = NULL;                           // Undirected advertisement.
    m_adv_params.fp          = BLE_GAP_ADV_FP_ANY;
    m_adv_params.interval    = APP_ADV_INTERVAL;
    m_adv_params.timeout     = APP_ADV_TIMEOUT_IN_SECONDS;
}


#ifdef BLE_DFU_APP_SUPPORT    
static void advertising_stop(void)
{
    uint32_t err_code;

    err_code = sd_ble_gap_adv_stop();
    APP_ERROR_CHECK(err_code);

    err_code = bsp_indication_set(BSP_INDICATE_IDLE);
    APP_ERROR_CHECK(err_code);
}


/** @snippet [DFU BLE Reset prepare] */
static void reset_prepare(void)
{
    uint32_t err_code;
    
    if (m_conn_handle != BLE_CONN_HANDLE_INVALID)
    {
        // Disconnect from peer.
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        APP_ERROR_CHECK(err_code);
        err_code = bsp_indication_set(BSP_INDICATE_IDLE);
        APP_ERROR_CHECK(err_code);
    }
    else
    {
        // If not connected, then the device will be advertising. Hence stop the advertising.
        advertising_stop();
    }

    err_code = ble_conn_params_stop();
    APP_ERROR_CHECK(err_code);
}
/** @snippet [DFU BLE Reset prepare] */
#endif // BLE_DFU_APP_SUPPORT    


/**@brief Function for initializing services that will be used by the application.
 *
 * @details Initialize the Heart Rate, Battery and Device Information services.
 */
static void services_init(void)
{
    uint32_t       err_code;
    ble_hrs_init_t hrs_init;
    ble_bas_init_t bas_init;
    ble_dis_init_t dis_init;
    uint8_t        body_sensor_location;

    // Initialize Heart Rate Service.
    body_sensor_location = BLE_HRS_BODY_SENSOR_LOCATION_FINGER;

    memset(&hrs_init, 0, sizeof(hrs_init));

    hrs_init.evt_handler                 = NULL;
    hrs_init.is_sensor_contact_supported = true;
    hrs_init.p_body_sensor_location      = &body_sensor_location;

    // Here the sec level for the Heart Rate Service can be changed/increased.
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&hrs_init.hrs_hrm_attr_md.cccd_write_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&hrs_init.hrs_hrm_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&hrs_init.hrs_hrm_attr_md.write_perm);

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&hrs_init.hrs_bsl_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&hrs_init.hrs_bsl_attr_md.write_perm);

    err_code = ble_hrs_init(&m_hrs, &hrs_init);
    APP_ERROR_CHECK(err_code);

    // Initialize Battery Service.
    memset(&bas_init, 0, sizeof(bas_init));

    // Here the sec level for the Battery Service can be changed/increased.
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&bas_init.battery_level_char_attr_md.cccd_write_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&bas_init.battery_level_char_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&bas_init.battery_level_char_attr_md.write_perm);

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&bas_init.battery_level_report_read_perm);

    bas_init.evt_handler          = NULL;
    bas_init.support_notification = true;
    bas_init.p_report_ref         = NULL;
    bas_init.initial_batt_level   = 100;

    err_code = ble_bas_init(&m_bas, &bas_init);
    APP_ERROR_CHECK(err_code);

    // Initialize Device Information Service.
    memset(&dis_init, 0, sizeof(dis_init));

    ble_srv_ascii_to_utf8(&dis_init.manufact_name_str, (char *)MANUFACTURER_NAME);

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&dis_init.dis_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&dis_init.dis_attr_md.write_perm);

    err_code = ble_dis_init(&dis_init);
    APP_ERROR_CHECK(err_code);
    
#ifdef BLE_DFU_APP_SUPPORT    
    /** @snippet [DFU BLE Service initialization] */
    ble_dfu_init_t   dfus_init;

    // Initialize the Device Firmware Update Service.
    memset(&dfus_init, 0, sizeof(dfus_init));

    dfus_init.evt_handler    = dfu_app_on_dfu_evt;
    dfus_init.error_handler  = NULL; //service_error_handler - Not used as only the switch from app to DFU mode is required and not full dfu service.
    dfus_init.evt_handler    = dfu_app_on_dfu_evt;
    dfus_init.revision       = DFU_REVISION;

    err_code = ble_dfu_init(&m_dfus, &dfus_init);
    APP_ERROR_CHECK(err_code);
    
    dfu_app_reset_prepare_set(reset_prepare);
    /** @snippet [DFU BLE Service initialization] */
#endif // BLE_DFU_APP_SUPPORT    
}


/**@brief Function for initializing the sensor simulators.
 */
static void sensor_sim_init(void)
{
    m_battery_sim_cfg.min          = MIN_BATTERY_LEVEL;
    m_battery_sim_cfg.max          = MAX_BATTERY_LEVEL;
    m_battery_sim_cfg.incr         = BATTERY_LEVEL_INCREMENT;
    m_battery_sim_cfg.start_at_max = true;

    ble_sensorsim_init(&m_battery_sim_state, &m_battery_sim_cfg);

    m_heart_rate_sim_cfg.min          = MIN_HEART_RATE;
    m_heart_rate_sim_cfg.max          = MAX_HEART_RATE;
    m_heart_rate_sim_cfg.incr         = HEART_RATE_INCREMENT;
    m_heart_rate_sim_cfg.start_at_max = false;

    ble_sensorsim_init(&m_heart_rate_sim_state, &m_heart_rate_sim_cfg);

    m_rr_interval_sim_cfg.min          = MIN_RR_INTERVAL;
    m_rr_interval_sim_cfg.max          = MAX_RR_INTERVAL;
    m_rr_interval_sim_cfg.incr         = RR_INTERVAL_INCREMENT;
    m_rr_interval_sim_cfg.start_at_max = false;

    ble_sensorsim_init(&m_rr_interval_sim_state, &m_rr_interval_sim_cfg);
}


/**@brief Function for starting application timers.
 */
static void application_timers_start(void)
{
    uint32_t err_code;

    // Start application timers.
    err_code = app_timer_start(m_battery_timer_id, BATTERY_LEVEL_MEAS_INTERVAL, NULL);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_start(m_heart_rate_timer_id, HEART_RATE_MEAS_INTERVAL, NULL);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_start(m_rr_interval_timer_id, RR_INTERVAL_INTERVAL, NULL);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_start(m_sensor_contact_timer_id, SENSOR_CONTACT_DETECTED_INTERVAL, NULL);
    APP_ERROR_CHECK(err_code);

    // err_code = app_timer_start(m_adc_timer_id, ADC_SAMPLING_INTERVAL, NULL);
    // APP_ERROR_CHECK(err_code);
}


/**@brief Function for starting advertising.
 */
static void advertising_start(void)
{
    uint32_t err_code;
    uint32_t count;

    // Verify if there is any flash access pending, if yes delay starting advertising until
    // it's complete.
    err_code = pstorage_access_status_get(&count);
    APP_ERROR_CHECK(err_code);

    if (count != 0)
    {
        m_memory_access_in_progress = true;
        return;
    }

    err_code = sd_ble_gap_adv_start(&m_adv_params);
    APP_ERROR_CHECK(err_code);

    err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling the Connection Parameters Module.
 *
 * @details This function will be called for all events in the Connection Parameters Module which
 *          are passed to the application.
 *          @note All this function does is to disconnect. This could have been done by simply
 *                setting the disconnect_on_fail config parameter, but instead we use the event
 *                handler mechanism to demonstrate its use.
 *
 * @param[in]   p_evt   Event received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    uint32_t err_code;

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)
    {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}


/**@brief Function for handling a Connection Parameters error.
 *
 * @param[in]   nrf_error   Error code containing information about what went wrong.
 */
static void conn_params_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}


/**@brief Function for initializing the Connection Parameters module.
 */
static void conn_params_init(void)
{
    uint32_t               err_code;
    ble_conn_params_init_t cp_init;

    memset(&cp_init, 0, sizeof(cp_init));

    cp_init.p_conn_params                  = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle    = m_hrs.hrm_handles.cccd_handle;
    cp_init.disconnect_on_fail             = false;
    cp_init.evt_handler                    = on_conn_params_evt;
    cp_init.error_handler                  = conn_params_error_handler;

    err_code = ble_conn_params_init(&cp_init);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling the Application's BLE Stack events.
 *
 * @param[in]   p_ble_evt   Bluetooth stack event.
 */
static void on_ble_evt(ble_evt_t * p_ble_evt)
{
    uint32_t err_code;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:

            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);
            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
            break;

        case BLE_GAP_EVT_DISCONNECTED:
            err_code = bsp_indication_set(BSP_INDICATE_IDLE);
            APP_ERROR_CHECK(err_code);
            advertising_start();
            break;

        case BLE_GAP_EVT_TIMEOUT:

            if (p_ble_evt->evt.gap_evt.params.timeout.src == BLE_GAP_TIMEOUT_SRC_ADVERTISEMENT)
            {
                err_code = bsp_indication_set(BSP_INDICATE_IDLE);
                APP_ERROR_CHECK(err_code);

                // enable buttons to wake-up from power off
                err_code = bsp_buttons_enable( (1 << WAKEUP_BUTTON_ID) | (1 << BOND_DELETE_ALL_BUTTON_ID) );
                APP_ERROR_CHECK(err_code);

                // Go to system-off mode (this function will not return; wakeup will cause a reset).
                err_code = sd_power_system_off();
                APP_ERROR_CHECK(err_code);
            }
            break;

        default:
            // No implementation needed.
            break;
    }
}


/**@brief Function for handling the Application's system events.
 *
 * @param[in]   sys_evt   system event.
 */
static void on_sys_evt(uint32_t sys_evt)
{
    switch(sys_evt)
    {
        case NRF_EVT_FLASH_OPERATION_SUCCESS:
        case NRF_EVT_FLASH_OPERATION_ERROR:

            if (m_memory_access_in_progress)
            {
                m_memory_access_in_progress = false;
                advertising_start();
            }
            break;

        default:
            // No implementation needed.
            break;
    }
}


/**@brief Function for dispatching a BLE stack event to all modules with a BLE stack event handler.
 *
 * @details This function is called from the BLE Stack event interrupt handler after a BLE stack
 *          event has been received.
 *
 * @param[in]   p_ble_evt   Bluetooth stack event.
 */
static void ble_evt_dispatch(ble_evt_t * p_ble_evt)
{
    dm_ble_evt_handler(p_ble_evt);
    ble_hrs_on_ble_evt(&m_hrs, p_ble_evt);
    ble_bas_on_ble_evt(&m_bas, p_ble_evt);
    ble_conn_params_on_ble_evt(p_ble_evt);
#ifdef BLE_DFU_APP_SUPPORT    
    /** @snippet [Propagating BLE Stack events to DFU Service] */
    ble_dfu_on_ble_evt(&m_dfus, p_ble_evt);
    /** @snippet [Propagating BLE Stack events to DFU Service] */
#endif // BLE_DFU_APP_SUPPORT    
    on_ble_evt(p_ble_evt);
}


/**@brief Function for dispatching a system event to interested modules.
 *
 * @details This function is called from the System event interrupt handler after a system
 *          event has been received.
 *
 * @param[in]   sys_evt   System stack event.
 */
static void sys_evt_dispatch(uint32_t sys_evt)
{
    pstorage_sys_event_handler(sys_evt);
    on_sys_evt(sys_evt);
}


/**@brief Function for initializing the BLE stack.
 *
 * @details Initializes the SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void)
{
    uint32_t err_code;

    // Initialize the SoftDevice handler module.
    SOFTDEVICE_HANDLER_INIT(NRF_CLOCK_LFCLKSRC_XTAL_20_PPM, false);

#if defined(S110) || defined(S310)
    // Enable BLE stack 
    ble_enable_params_t ble_enable_params;
    memset(&ble_enable_params, 0, sizeof(ble_enable_params));
    ble_enable_params.gatts_enable_params.service_changed = IS_SRVC_CHANGED_CHARACT_PRESENT;
    err_code = sd_ble_enable(&ble_enable_params);
    APP_ERROR_CHECK(err_code);
#endif

    // Register with the SoftDevice handler module for BLE events.
    err_code = softdevice_ble_evt_handler_set(ble_evt_dispatch);
    APP_ERROR_CHECK(err_code);

    // Register with the SoftDevice handler module for BLE events.
    err_code = softdevice_sys_evt_handler_set(sys_evt_dispatch);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling the Device Manager events.
 *
 * @param[in]   p_evt   Data associated to the device manager event.
 */
static uint32_t device_manager_evt_handler(dm_handle_t const * p_handle,
                                           dm_event_t const  * p_event,
                                           api_result_t        event_result)
{
    APP_ERROR_CHECK(event_result);
    
    switch(p_event->event_id)
    {
#ifdef BLE_DFU_APP_SUPPORT    
        case DM_EVT_DEVICE_CONTEXT_LOADED: // Fall through.
        case DM_EVT_SECURITY_SETUP_COMPLETE:
            dfu_app_set_dm_handle(p_handle);
            break;
        case DM_EVT_DISCONNECTION:
            dfu_app_set_dm_handle(NULL);
            break;
#endif // BLE_DFU_APP_SUPPORT    
    }

    return NRF_SUCCESS;
}


/**@brief Function for the Device Manager initialization.
 */
static void device_manager_init(void)
{
    uint32_t               err_code;
    dm_init_param_t        init_data;
    dm_application_param_t register_param;

    // Initialize persistent storage module.
    err_code = pstorage_init();
    APP_ERROR_CHECK(err_code);

    // Clear all bonded centrals if the Bonds Delete button is pushed.
    err_code = bsp_button_is_pressed(BOND_DELETE_ALL_BUTTON_ID,&(init_data.clear_persistent_data));
    APP_ERROR_CHECK(err_code);

    err_code = dm_init(&init_data);
    APP_ERROR_CHECK(err_code);

    memset(&register_param.sec_param, 0, sizeof(ble_gap_sec_params_t));
    
    register_param.sec_param.timeout      = SEC_PARAM_TIMEOUT;
    register_param.sec_param.bond         = SEC_PARAM_BOND;
    register_param.sec_param.mitm         = SEC_PARAM_MITM;
    register_param.sec_param.io_caps      = SEC_PARAM_IO_CAPABILITIES;
    register_param.sec_param.oob          = SEC_PARAM_OOB;
    register_param.sec_param.min_key_size = SEC_PARAM_MIN_KEY_SIZE;
    register_param.sec_param.max_key_size = SEC_PARAM_MAX_KEY_SIZE;
    register_param.evt_handler            = device_manager_evt_handler;
    register_param.service_type           = DM_PROTOCOL_CNTXT_GATT_SRVR_ID;

    err_code = dm_register(&m_app_handle, &register_param);
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for the Power manager.
 */
static void power_manage(void)
{
    uint32_t err_code = sd_app_evt_wait();
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for application main entry.
 */
int main(void)
{
    // Initialize.

    uart_config();
    printf("\n\rADC HAL simple example\r\n");

    printf("Current sample value:\r\n");

	// simple_uart_config(RTS_PIN_NUMBER, TX_PIN_NUMBER, CTS_PIN_NUMBER, RX_PIN_NUMBER, HWFC);
	uart_start();
	adc_config();
    debug_msg("hello this is test : %d", 10);
    // for (int i = 0; i < 100; i++){
    //     nrf_adc_start();
    // }

    ble_stack_init();

    // nrf_adc_start();
    // if (NRF_SUCCESS != sd_clock_hfclk_is_running(1))
    // {
    //     lfclk_config();
    //     /* code */
    // }
    init_leds();
    timers_init();
    APP_GPIOTE_INIT(APP_GPIOTE_MAX_USERS);
    init_button();


    //uint32_t err_code = bsp_init(BSP_INIT_LED | BSP_INIT_BUTTONS, APP_TIMER_TICKS(100, APP_TIMER_PRESCALER), NULL);
//    APP_ERROR_CHECK(err_code);

    device_manager_init();
    gap_params_init();
    advertising_init();
    services_init();
    sensor_sim_init();
    conn_params_init();

    // Start execution.
    application_timers_start();
    advertising_start();
    // timer_start();
    // lfclk_config();
    // rtc_config();

    // Enter main loop.
    for (;; )
    {
        switch (m_state) {
            case IDLE:
                break;
            case DATA:
                break;
            case COMPUTE:
                dark_force();
                m_state = FFT;
                break;
            case FFT:
                m_state = IDLE;
                break;
            default:
                break;
        }
        power_manage();
    }
}







double indexToFreq(int i,double sample_rate,int nFFT)
{
    return (double) i*(sample_rate/(nFFT));
}

int findMax(unsigned char *array,int length)
{
    int max = -1;
    for (int i =1; i<length; i++) {
        if (array[i]>=max) {
            max = array[i];
        }
        else{
            //MAX FOUND
            return i-1;
        }
    }
    return -1;
}


void swap(double *a, double *b)
{
	double temp = *a;
	*a = *b;
	*b = temp;
}
/*
 @file FFT.cpp
 @version: 1.0
 @author: Suky
 @web www.micros-designs.com.ar
 @date 10/02/11
 */
// Extracted from Numerical Recipes in C
void vFFT(double data[], unsigned int nn){
    /*Replaces data[1..2*nn] by its discrete Fourier transform, if isign is input as 1; or replaces
     data[1..2*nn] by nn times its inverse discrete Fourier transform, if isign is input as -1.
     data is a complex array of length nn or, equivalently, a real array of length 2*nn. nn MUST
     be an integer power of 2 (this is not checked for!).*/
    unsigned int n,mmax,m,j,istep,i;
    double wtemp,wr,wpr,wpi,wi,theta;
    double tempr,tempi;
    debug_msg("Inside a FFT");
//#define SWAP(a,b) tempr=(a);(a)=(b);(b)=tempr
    
    n=nn << 1;
    j=1;
    for (i=1;i<n;i+=2) {
        if(j>i){
            swap(data+j,data+i);
            swap(data+j+1,data+i+1);
        }
        m=n >> 1;
        while (m >= 2 &&j>m){
            j-=m;
            m >>= 1;
        }
        j+=m;
    }
    
    mmax=2;
    while (n > mmax) {
        istep=mmax << 1;
        theta=(6.28318530717959/mmax);
        wtemp=sin(0.5*theta);
        wpr = -2.0*wtemp*wtemp;
        wpi=sin(theta);
        wr=1.0;
        wi=0.0;
        for (m=1;m<mmax;m+=2) {
            for (i=m;i<=n;i+=istep) {
                j=i+mmax;
                tempr=wr*data[j]-wi*data[j+1];
                tempi=wr*data[j+1]+wi*data[j];
                data[j]=data[i]-tempr;
                data[j+1]=data[i+1]-tempi;
                data[i] += tempr;
                data[i+1] += tempi;
            }
            wr=(wtemp=wr)*wpr-wi*wpi+wr;
            wi=wi*wpr+wtemp*wpi+wi;
        }
        mmax=istep;
    }
}

// Extracted from Numerical Recipes in C
void vRealFFT(double data[], unsigned int n){
    /*Calculates the Fourier transform of a set of n real-valued data points. Replaces this data (which
     is stored in array data[1..n]) by the positive frequency half of its complex Fourier transform.
     The real-valued rst and last components of the complex transform are returned as elements
     data[1] and data[2], respectively. n must be a power of 2. This routine also calculates the
     inverse transform of a complex data array if it is the transform of real data. (Result in this case
     must be multiplied by 2/n.)*/
    unsigned long i,i1,i2,i3,i4,np3;
    double c1=0.5,c2,h1r,h1i,h2r,h2i;
    double wr,wi,wpr,wpi,wtemp,theta;
    theta=3.141592653589793/(double) (n>>1);
    
    c2 = -0.5;
    vFFT(data,n>>1);
    wtemp=sin(0.5*theta);
    wpr = -2.0*wtemp*wtemp;
    wpi=sin(theta);
    wr=1.0+wpr;
    wi=wpi;
    np3=n+3;
    for (i=2;i<=(n>>2);i++) {
        i4=1+(i3=np3-(i2=1+(i1=i+i-1)));
        h1r=c1*(data[i1]+data[i3]);
        h1i=c1*(data[i2]-data[i4]);
        h2r = -c2*(data[i2]+data[i4]);
        h2i=c2*(data[i1]-data[i3]);
        data[i1]=h1r+wr*h2r-wi*h2i;
        data[i2]=h1i+wr*h2i+wi*h2r;
        data[i3]=h1r-wr*h2r+wi*h2i;
        data[i4] = -h1i+wr*h2i+wi*h2r;
        wr=(wtemp=wr)*wpr-wi*wpi+wr;
        wi=wi*wpr+wtemp*wpi+wi;
    }
    data[1] = (h1r=data[1])+data[2];
    data[2] = h1r-data[2];
    
}


void vCalPowerf(double Input[],double Power[], unsigned int n){
    unsigned char k,j;
    
    for(k=0,j=0;k<n;k++,j+=2){
        Power[k]=sqrt(Input[j]*Input[j]+Input[j+1]*Input[j+1]);
    }
}

void vCalPowerInt(double Input[],unsigned char Power[], unsigned int n){
    unsigned char k,j;
    
    for(k=0,j=0;k<n;k++,j+=2){
        Power[k]=sqrt(Input[j]*Input[j]+Input[j+1]*Input[j+1]);
    }
}

void vCalPowerLog(double Input[],unsigned char Power[], unsigned int n){
    unsigned char k,j;
    double Temp;
    
    for(k=0,j=0;k<n;k++,j+=2){
        if((Input[j]!=0) && (Input[j+1]!=0)){
            Temp=sqrt(Input[j]*Input[j]+Input[j+1]*Input[j+1]);
            Power[k]=10.0*log10(Temp);
        }else{
            Power[k]=0;
        }
    }
    
}

