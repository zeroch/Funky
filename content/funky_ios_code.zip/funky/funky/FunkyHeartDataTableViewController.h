//
//  FunkyHeartDataTableViewController.h
//  funky
//
//  Created by zchen78 on 2/15/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface FunkyHeartDataTableViewController : UITableViewController

@end
