//
//  FunkyPageViewController.m
//  funky
//
//  Created by zchen78 on 3/29/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyPageViewController.h"
#import "FunkyDisplayViewController.h"
#import "FunkyHeartDataDetailViewController.h"
#import "FunkyStatisticsViewController.h"


@interface FunkyPageViewController ()

@end

@implementation FunkyPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataSource = self;
    [self.storyboard instantiateViewControllerWithIdentifier:@"statisticsVC"];
    [self setViewControllers:@[[self.storyboard instantiateViewControllerWithIdentifier:@"statisticsVC"]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    self.delegate = self;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    if ([viewController isKindOfClass:[FunkyStatisticsViewController class]])
        return nil;
    
    return [self.storyboard instantiateViewControllerWithIdentifier:@"statisticsVC"];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    if ([viewController isKindOfClass:[FunkyDisplayViewController class]])
        return nil;
    
    return [self.storyboard instantiateViewControllerWithIdentifier:@"summaryVC"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
