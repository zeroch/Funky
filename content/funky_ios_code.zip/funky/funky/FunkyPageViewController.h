//
//  FunkyPageViewController.h
//  funky
//
//  Created by zchen78 on 3/29/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FunkyPageViewController : UIPageViewController<UIPageViewControllerDataSource,UIPageViewControllerDelegate>

@end
