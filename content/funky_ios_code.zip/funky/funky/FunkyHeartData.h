//
//  FunkyHeartData.h
//  funky
//
//  Created by zchen78 on 2/13/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FunkyHeartData : NSObject <NSCoding>

@property(nonatomic,strong,readonly)NSNumber * oxygenSaturation;
@property(nonatomic,strong,readonly)NSNumber * heartRate;
@property(nonatomic,strong,readonly)NSDate *timestamp;
@property(nonatomic,readonly)BOOL isOxygenSaturation;


+(instancetype)newRandomFunkyHeartData;
-(instancetype)initWithOxygenSaturation:(float)oxygenSaturation
                                       heartRate:(unsigned)heartRate
                                       timeSinceReferenceDate:(NSTimeInterval)timeSinceReferenceDate
                                        isOxygenSaturation:(BOOL)isOxygenSaturation;

@end

