//
//  AppDelegate.h
//  funky
//
//  Created by zchen78 on 2/13/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

