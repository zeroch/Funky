//
//  FunkyHeartDataStore.h
//  funky
//
//  Created by zchen78 on 2/14/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <Foundation/Foundation.h>
@import HealthKit;

@class FunkyHeartData;

@interface FunkyHeartDataStore : NSObject

@property (nonatomic,readonly)NSArray *allData;
@property(nonatomic) HKHealthStore *healthStore;

+(instancetype)sharedStore;

#pragma mark -modify storage
-(void)addFunkyHeartDataEntry:(FunkyHeartData *)funkyHeartDataEntry;

-(BOOL)saveChange;
-(void)removeFunkyHeartDataEntry:(FunkyHeartData *)funkyHeartDataEntry;
- (void)moveItemAtIndex:(NSInteger)fromIndex
                toIndex:(NSInteger)toIndex;

#pragma mark -statistics 
//TODO
//Ideally we will query the data from HKHealthStore
//But now I am just using the temporaray cache statistics value;

-(unsigned int)averageHeartRate;
-(float)averageOxygenSaturation;
-(NSArray *)sortedHeartRateArray;
-(NSArray *)sortedOxygenSaturationArray;
-(void)clear;
@end
