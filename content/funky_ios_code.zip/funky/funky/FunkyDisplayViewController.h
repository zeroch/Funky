//
//  FunkyDisplayViewController.h
//  funky
//
//  Created by zchen78 on 3/7/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "ScannerDelegate.h"

@interface FunkyDisplayViewController : UIViewController <CBCentralManagerDelegate, CBPeripheralDelegate, ScannerDelegate>

@property (strong, nonatomic) CBCentralManager *bluetoothManager;



@end
