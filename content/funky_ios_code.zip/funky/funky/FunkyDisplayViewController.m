//
//  FunkyDisplayViewController.m
//  funky
//
//  Created by zchen78 on 3/7/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyDisplayViewController.h"
#import "Constants.h"
#import "ScannerViewController.h"
#import "FunkyHeartData.h"
#import "FunkyHeartDataStore.h"



@interface FunkyDisplayViewController ()
{
    BOOL isBluetoothON;
    BOOL isDeviceConnected;
    BOOL isBackButtonPressed;
    
    CBUUID *HR_Service_UUID;
    CBUUID *HR_Measurement_Characteristic_UUID;
    CBUUID *HR_Location_Characteristic_UUID;
    CBUUID *Battery_Service_UUID;
    CBUUID *Battery_Level_Characteristic_UUID;
    CBUUID *dfuService_UUID;
    CBUUID *dfuControl_Point_Characteristic_UUID;
    CBUUID *dfuPacket_Characteristic_UUID;
    CBUUID *SPO_Service_UUID;
    CBUUID *SPO_Measurement_Characteristic_UUID;
}
@property (strong, nonatomic) CBPeripheral *funkyPeripheral;

@property (weak, nonatomic) IBOutlet UILabel *HeartRateLabel;
@property (weak, nonatomic) IBOutlet UILabel *OxygenSaturtionLabel;
@property (weak, nonatomic) IBOutlet UILabel *HRLabel;
@property (weak, nonatomic) IBOutlet UILabel *OSLabel;

@end

@implementation FunkyDisplayViewController

@synthesize bluetoothManager;
@synthesize funkyPeripheral;

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Custom initialization
        HR_Service_UUID = [CBUUID UUIDWithString:hrsServiceUUIDString];
        HR_Measurement_Characteristic_UUID = [CBUUID UUIDWithString:hrsHeartRateCharacteristicUUIDString];
        HR_Location_Characteristic_UUID = [CBUUID UUIDWithString:hrsSensorLocationCharacteristicUUIDString];
        Battery_Service_UUID = [CBUUID UUIDWithString:batteryServiceUUIDString];
        Battery_Level_Characteristic_UUID = [CBUUID UUIDWithString:batteryLevelCharacteristicUUIDString];
        SPO_Service_UUID = [CBUUID UUIDWithString:spoServiceUUIDString];
        SPO_Measurement_Characteristic_UUID = [CBUUID UUIDWithString:spoCharacteristicUUIDString];
    }
    return self;
}

-(void)bringScanVC:(UIGestureRecognizer *)gr{
    NSLog(@"swipeDown");
    [self performSegueWithIdentifier:@"scan" sender:nil];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    funkyPeripheral = nil;
    
    UITapGestureRecognizer *doubleTapBringScanVC = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(bringScanVC:)];
    doubleTapBringScanVC.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:doubleTapBringScanVC];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    NSLog(@"viewWillAppear");
}

-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // The 'scan' seque will be performed only if connectedPeripheral == nil (if we are not connected already).
    return ![identifier isEqualToString:@"scan"] || funkyPeripheral == nil;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"scan"])
    {
        NSLog(@"prepareForSegue scan");
        // Set this contoller as scanner delegate
        ScannerViewController *controller = (ScannerViewController *)segue.destinationViewController;
        //bluetoothManager delegate set here
        controller.delegate = self;
    }
}

//TODO
-(void)appDidEnterBackground:(NSNotification *)_notification
{
    
}

-(void)appDidBecomeActiveBackground:(NSNotification *)_notification
{
    
}

#pragma mark Scanner Delegate methods

-(void)centralManager:(CBCentralManager *)manager didPeripheralSelected:(CBPeripheral *)peripheral
{
    // We may not use more than one Central Manager instance. Let's just take the one returned from Scanner View Controller
    
    bluetoothManager = manager;
    bluetoothManager.delegate = self;
    NSLog(@"Select the device");
    // The sensor has been selected, connect to it
    funkyPeripheral = peripheral;
    funkyPeripheral.delegate = self;
    NSDictionary *options = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:CBConnectPeripheralOptionNotifyOnNotificationKey];
    [bluetoothManager connectPeripheral:funkyPeripheral options:options];
}

#pragma mark Central Manager delegate methods

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state == CBCentralManagerStatePoweredOn) {
        // TODO
        NSLog(@"Device is Powered On");
    }
    else
    {
        // TODO
        NSLog(@"Bluetooth not ON");
    }
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    
    NSLog(@"Connect Device");
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidBecomeActiveBackground:) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    // Peripheral has connected. Discover any services
    [funkyPeripheral discoverServices:nil];
}

-(void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    // Scanner uses other queue to send events. We must edit UI in the main queue
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Connecting to the peripheral failed. Try again" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        funkyPeripheral = nil;
    });
}


- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    // Scanner uses other queue to send events. We must edit UI in the main queue
    dispatch_async(dispatch_get_main_queue(), ^{
        funkyPeripheral = nil;
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
    });
}

#pragma mark Peripheral delegate methods

-(void) peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    NSLog(@"didDiscoverServices");
    if (!error) {
        for (CBService *service in peripheral.services) {
            if ([service.UUID isEqual:HR_Service_UUID])
            {
                NSLog(@"HR service found");
                [funkyPeripheral discoverCharacteristics:nil forService:service];
            }
            else if ([service.UUID isEqual:Battery_Service_UUID])
            {
                NSLog(@"Battery service found");
                [funkyPeripheral discoverCharacteristics:nil forService:service];
            }
            // code to discover DFU Service
            else if ([service.UUID isEqual:dfuService_UUID]) {
                NSLog(@"DFU Service is found");
                [funkyPeripheral discoverCharacteristics:nil forService:service];
            }
            
            else if ([service.UUID isEqual:SPO_Service_UUID]){
                NSLog(@"SPO Service is found");
                [funkyPeripheral discoverCharacteristics:nil forService:service];
            }
        }
    } else {
        NSLog(@"error in discovering services on device: %@",funkyPeripheral.name);
    }
}

-(void) peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    if (!error) {
        if ([service.UUID isEqual:HR_Service_UUID]) {
            for (CBCharacteristic *characteristic in service.characteristics)
            {
                if ([characteristic.UUID isEqual:HR_Measurement_Characteristic_UUID]) {
                    NSLog(@"HR Measurement characteritsic is found");
                    [funkyPeripheral setNotifyValue:YES forCharacteristic:characteristic ];
                }
                else if ([characteristic.UUID isEqual:HR_Location_Characteristic_UUID]) {
                    NSLog(@"HR Position characteristic is found");
                    [funkyPeripheral readValueForCharacteristic:characteristic];
                }
            }
        }
        else if ([service.UUID isEqual:Battery_Service_UUID]) {
            
            for (CBCharacteristic *characteristic in service.characteristics)
            {
                if ([characteristic.UUID isEqual:Battery_Level_Characteristic_UUID]) {
                    NSLog(@"Battery Level characteristic is found");
                   // [funkyPeripheral readValueForCharacteristic:characteristic];
                    [funkyPeripheral setNotifyValue:YES forCharacteristic:characteristic];
                }
            }
        }
        else if([service.UUID isEqual:SPO_Service_UUID]){
            for (CBCharacteristic *characteristic in service.characteristics) {
                if ([characteristic.UUID isEqual:SPO_Measurement_Characteristic_UUID]) {
                    NSLog(@"SPO Measurement Characteristic is found");
                    [funkyPeripheral setNotifyValue:YES forCharacteristic:characteristic];
                }
            }
        }
    }
    else{
            NSLog(@"error in discovering characteristic on device: %@",funkyPeripheral.name);
    }
}

-(void) peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!error) {
            NSLog(@"received update of value: %@, UUID: %@",characteristic.value,characteristic.UUID);
            if ([characteristic.UUID isEqual:HR_Measurement_Characteristic_UUID]) {
                NSLog(@"HRM value: %@",characteristic.value);
                unsigned int heartRate = [self decodeHRValue:characteristic.value];
                NSDate *now = [NSDate date];
                [self updateHeartRateLabel:heartRate];
                //add the HR value into FunkyDataStoreManager
                FunkyHeartData *hr_data = [[FunkyHeartData alloc]initWithOxygenSaturation:0.0 heartRate:heartRate timeSinceReferenceDate:[now timeIntervalSinceReferenceDate] isOxygenSaturation:FALSE];
                [[FunkyHeartDataStore sharedStore]addFunkyHeartDataEntry:hr_data];
            }
            else if ([characteristic.UUID isEqual:HR_Location_Characteristic_UUID]) {
              //  hrLocation.text = [self decodeHRLocation:characteristic.value];
                //TODO
                //Not sure what to do with the Location yet
            }
            else if ([characteristic.UUID isEqual:Battery_Level_Characteristic_UUID]) {
                //TODO
                //When Battery fall below 10%, create a notification warning.
                
            }
            else if([characteristic.UUID isEqual:SPO_Measurement_Characteristic_UUID]){
                
                NSLog(@"SPO value:%@",characteristic.value);
                float spo_value = [self decodeSpOValue:characteristic.value];
                NSDate *now = [NSDate date];
                [self updateOxygenSaturationLabel:spo_value];
                //add the SpO value into FunkyDataStoreManager
                FunkyHeartData *spo_data = [[FunkyHeartData alloc]initWithOxygenSaturation:spo_value heartRate:0 timeSinceReferenceDate:[now timeIntervalSinceReferenceDate]  isOxygenSaturation:TRUE];
                [[FunkyHeartDataStore sharedStore]addFunkyHeartDataEntry:spo_data];
            }
        }
        else {
            NSLog(@"error in update sensor value");
        }
    });
}

-(int) decodeHRValue:(NSData *)data
{
    const uint8_t *value = [data bytes];
    int bpmValue = 0;
    if ((value[0] & 0x01) == 0) {
        NSLog(@"8 bit HR Value");
        bpmValue = value[1];
    }
    else {
        NSLog(@"16 bit HR Value");
        bpmValue = CFSwapInt16LittleToHost(*(uint16_t *)(&value[1]));
    }
    NSLog(@"BPM: %d",bpmValue);
    return bpmValue;
}

-(float) decodeSpOValue:(NSData *)data
{
    const uint8_t *value = [data bytes];
    double spoValue = 0.0;
    //if ((value[0] & 0x01) == 0) {
    NSLog(@"8 bit SPO2 Value");
    spoValue = 100-(value[1]*16 + value[0])*(15.0/255.0);
    //}
    NSLog(@"SPO: %f",spoValue);
    return spoValue;}

-(NSString *) decodeHRLocation:(NSData *)data
{
    const uint8_t *location = [data bytes];
    NSString *hrmLocation;
    switch (location[0]) {
        case 0:
            hrmLocation = @"Other";
            break;
        case 1:
            hrmLocation = @"Chest";
            break;
        case 2:
            hrmLocation = @"Wrist";
            break;
        case 3:
            hrmLocation = @"Finger";
            break;
        case 4:
            hrmLocation = @"Hand";
            break;
        case 5:
            hrmLocation = @"Ear Lobe";
            break;
        case 6:
            hrmLocation = @"Foot";
            break;
        default:
            hrmLocation = @"Invalid";
            break;
    }
    NSLog(@"HRM location is %@",hrmLocation);
    return hrmLocation;
}


#pragma -mark 

-(void)updateHeartRateLabel:(int)data{

    self.HeartRateLabel.text = [NSString stringWithFormat:@"%d",data];
    if (data > 90) {
        self.HeartRateLabel.textColor = [UIColor redColor];
    }
    else{
        self.HeartRateLabel.textColor = [UIColor darkTextColor];
    }
}

-(void)updateOxygenSaturationLabel:(double)data{
    self.OxygenSaturtionLabel.text = [NSString stringWithFormat:@"%.2f",data];
    if (data < 85) {
        self.OxygenSaturtionLabel.textColor = [UIColor redColor];
    }
    else{
        self.OxygenSaturtionLabel.textColor = [UIColor darkTextColor];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

@end

