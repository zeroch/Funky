//
//  FunkyHeartDataStore.m
//  funky
//
//  Created by zchen78 on 2/14/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyHeartDataStore.h"
#import "FunkyHeartData.h"
@interface FunkyHeartDataStore()

@property(nonatomic,strong)NSMutableArray *privateData;

@end


@implementation FunkyHeartDataStore

static dispatch_queue_t _queue;

+(instancetype)sharedStore{
    
    static FunkyHeartDataStore *sharedStore;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!sharedStore) {
            sharedStore = [[self alloc]initPrivate];
            _queue = dispatch_queue_create("com.otherworldman.serialqueue", DISPATCH_QUEUE_SERIAL);
        }
    });
    return sharedStore;
}

// If a programmer calls [[BNRItemStore alloc] init], let him
// know the error of his ways
- (instancetype)init
{
    @throw [NSException exceptionWithName:@"Singleton"
                                   reason:@"Use +[FunkyHeartDataStore sharedStore]"
                                 userInfo:nil];
    return nil;
}

// Here is the real (secret) initializer
- (instancetype)initPrivate
{
    self = [super init];
    if (self) {
        NSString *path = [self itemArchivePath];
        _privateData = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
        
        // If the array hadn't been saved previously, create a new empty one
        if (!_privateData) {
            _privateData = [[NSMutableArray alloc] init];
        }
        if (!_healthStore) {
            _healthStore = [[HKHealthStore alloc]init];
        }
    }
    return self;
}

- (NSString *)itemArchivePath
{
    // Make sure that the first argument is NSDocumentDirectory
    // and not NSDocumentationDirectory
    NSArray *documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    // Get the one document directory from that list
    NSString *documentDirectory = [documentDirectories firstObject];
    
    return [documentDirectory stringByAppendingPathComponent:@"SampleTest7.archive"];
}

- (BOOL)saveChange
{
    NSString *path = [self itemArchivePath];
    
    // Returns YES on success
    return [NSKeyedArchiver archiveRootObject:self.privateData toFile:path];
}

-(void)addFunkyHeartDataEntry:(FunkyHeartData *)funkyHeartDataEntry{
    dispatch_sync(_queue, ^{
        [_privateData addObject:funkyHeartDataEntry];
        //write heart rate data and oxygenSaturation
        if (funkyHeartDataEntry.isOxygenSaturation) {
            HKQuantitySample *oxygenSaturationQuantitySample = [self oxygenSaturationQuantitySampleForFunkyHeartData:funkyHeartDataEntry];
            [self.healthStore saveObject:oxygenSaturationQuantitySample withCompletion:^(BOOL success,NSError *error){
                if (success) {
                }
                else {
                    NSLog(@"An error occured saving the funkyHeartData %@. In your app, try to handle this gracefully. The error was: %@.", funkyHeartDataEntry, error);
                    abort();
                }
            }];
        }
        else{
            HKQuantitySample *heartRateQuantitySample = [self heartRateQuantitySampleForFunkyHeartData:funkyHeartDataEntry];
    
            [self.healthStore saveObject:heartRateQuantitySample withCompletion:^(BOOL success,NSError *error){
                if (success) {
                }
                else {
                    NSLog(@"An error occured saving the funkyHeartData %@. In your app, try to handle this gracefully. The error was: %@.", funkyHeartDataEntry, error);
                    abort();
                }
            }];
        }
    });
}

-(void)removeFunkyHeartDataEntry:(FunkyHeartData *)funkyHeartDataEntry{
    dispatch_sync(_queue, ^{
        [_privateData removeObjectIdenticalTo:funkyHeartDataEntry];
        //TODO
        //Remove the data
    });

}

- (void)moveItemAtIndex:(NSInteger)fromIndex
                toIndex:(NSInteger)toIndex
{
    if (fromIndex == toIndex) {
        return;
    }
    // Get pointer to object being moved so you can re-insert it
    FunkyHeartData *FunkyHeartDataEntry = self.privateData[fromIndex];
    dispatch_sync(_queue, ^{
        // Remove item from array
        [self.privateData removeObjectAtIndex:fromIndex];
        // Insert item in array at new location
        [self.privateData insertObject:FunkyHeartDataEntry atIndex:toIndex];
    });
}

-(NSArray *)allData{
    return [self.privateData copy];
}

#pragma mark -HealthKit

-(HKQuantitySample *)heartRateQuantitySampleForFunkyHeartData:(FunkyHeartData *)funkyHeartData{
    
    HKQuantityType *heartRateQuantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeartRate];
    HKQuantity *heartRateQuantity = [HKQuantity quantityWithUnit:[[HKUnit countUnit] unitDividedByUnit:[HKUnit minuteUnit]] doubleValue:
                                     [funkyHeartData.heartRate doubleValue]
                                     ];

    
    
    
    HKQuantitySample *heartRateQuantitySample = [HKQuantitySample quantitySampleWithType:heartRateQuantityType quantity:heartRateQuantity startDate:funkyHeartData.timestamp endDate:funkyHeartData.timestamp];
    
    return heartRateQuantitySample;
}

-(HKQuantitySample *)oxygenSaturationQuantitySampleForFunkyHeartData:(FunkyHeartData *)funkyHeartData{
    
    HKQuantityType *oxygenSaturationQuantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierOxygenSaturation];
    HKQuantity *oxygenSaturationQuantity = [HKQuantity quantityWithUnit:[HKUnit percentUnit] doubleValue:([funkyHeartData.oxygenSaturation doubleValue])];
    HKQuantitySample *oxygenSaturationQuantitySample = [HKQuantitySample quantitySampleWithType:oxygenSaturationQuantityType quantity:oxygenSaturationQuantity startDate:funkyHeartData.timestamp endDate:funkyHeartData.timestamp];
    return oxygenSaturationQuantitySample;
    
}

#pragma mark -statistics 
-(unsigned int)averageHeartRate{
    int count = 0;
    int sum = 0;
    for (FunkyHeartData *entry in _privateData) {
        if (!entry.isOxygenSaturation) {
            count++;
            sum+=[entry.heartRate intValue];
        }
    }
    return sum/count;
}

-(float)averageOxygenSaturation{
    int count = 0;
    float sum = 0.0;
    for (FunkyHeartData *entry in _privateData) {
        if (entry.isOxygenSaturation) {
            count++;
            sum+=[entry.oxygenSaturation floatValue];
        }
    }
    return sum/count;
}

-(NSArray *)sortedHeartRateArray{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isOxygenSaturation==FALSE"];
    NSArray *filteredHeartArray = [_privateData filteredArrayUsingPredicate:predicate];
    NSArray *sortedArray ;
    sortedArray = [filteredHeartArray sortedArrayUsingComparator:^NSComparisonResult(id a, id b) {
        NSDate *first = [(FunkyHeartData*)a timestamp];
        NSDate *second = [(FunkyHeartData*)b timestamp];
        return [first compare:second];
    }];
    return sortedArray;
}

-(NSArray *)sortedOxygenSaturationArray{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isOxygenSaturation==TRUE"];
    NSArray *filteredOxygenSaturationArray = [_privateData filteredArrayUsingPredicate:predicate];
    NSArray *sortedArray ;
    sortedArray = [filteredOxygenSaturationArray sortedArrayUsingComparator:^NSComparisonResult(id a, id b) {
        NSDate *first = [(FunkyHeartData*)a timestamp];
        NSDate *second = [(FunkyHeartData*)b timestamp];
        return [first compare:second];
    }];
    
    return sortedArray;
}

-(void)clear{
    [_privateData removeAllObjects];
}

@end
