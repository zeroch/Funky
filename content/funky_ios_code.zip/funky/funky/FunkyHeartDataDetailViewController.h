//
//  FunkyHeartDataDetailViewController.h
//  funky
//
//  Created by zchen78 on 2/15/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FunkyHeartData;

@interface FunkyHeartDataDetailViewController : UIViewController

@property (nonatomic,strong)FunkyHeartData *entry;

@end
