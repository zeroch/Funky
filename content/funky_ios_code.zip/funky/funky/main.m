//
//  main.m
//  funky
//
//  Created by zchen78 on 2/13/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
