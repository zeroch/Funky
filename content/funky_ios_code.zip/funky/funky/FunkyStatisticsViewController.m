//
//  FunkyStatisticsViewController.m
//  funky
//
//  Created by zchen78 on 3/17/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyStatisticsViewController.h"
#import "FunkyHeartData.h"
#import "FunkyHeartDataStore.h"

#define DEBUG 1

@interface FunkyStatisticsViewController ()
@property (weak, nonatomic) IBOutlet UILabel *summaryTitle;
@end

@implementation FunkyStatisticsViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSArray *sortedHeartRateArray = [[FunkyHeartDataStore sharedStore]sortedHeartRateArray];
    NSArray *sortedOxygenSaturationArray = [[FunkyHeartDataStore sharedStore]sortedOxygenSaturationArray];
    NSMutableArray *heartRateValueArray = [[NSMutableArray alloc]init];
    for (FunkyHeartData *entry in sortedHeartRateArray) {
        if (entry.heartRate) {
            [heartRateValueArray addObject:entry.heartRate];
        }
    }
    NSMutableArray *oxygenSaturationValueArray = [[NSMutableArray alloc]init];
    for (FunkyHeartData *data in sortedOxygenSaturationArray) {
        if (data.oxygenSaturation) {
            [oxygenSaturationValueArray addObject:data.oxygenSaturation];
        }
    }
    graph = [MPPlot plotWithType:MPPlotTypeGraph frame:CGRectMake(0, 230, self.view.width, 150)];
    graph2 = [[MPGraphView alloc] initWithFrame:graph.frame];
    graph2.waitToUpdate = YES;
    graph2.values = heartRateValueArray;
    graph2.graphColor = [UIColor redColor];
    graph2.curved = YES;
    [self.view addSubview:graph2];
    graph3 = [[MPGraphView alloc] initWithFrame:CGRectMake(0, 420, self.view.width, 150)];
    graph3.waitToUpdate = YES;
    graph3.values = oxygenSaturationValueArray;
    graph3.curved = YES;
    graph3.graphColor = [UIColor colorWithRed:0.500 green:0.158 blue:1.000 alpha:1.000];
    graph3.detailBackgroundColor = [UIColor colorWithRed:0.444 green:0.842 blue:1.000 alpha:1.000];
    [self.view addSubview:graph3];
    [self performSelector:@selector(animate) withObject:nil afterDelay:0];
    UISwipeGestureRecognizer *swipeUpBringFunkyHeartDataTavleViewController = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(bringFakeVC:)];
    [swipeUpBringFunkyHeartDataTavleViewController setDirection:UISwipeGestureRecognizerDirectionUp];
    [self.view addGestureRecognizer:swipeUpBringFunkyHeartDataTavleViewController];
    [self updateSummartyView];
}

-(void)updateSummartyView{
    int avg_hr = [[FunkyHeartDataStore sharedStore]averageHeartRate];
    float avg_spo = [[FunkyHeartDataStore sharedStore]averageOxygenSaturation];
    NSString *text= [NSString stringWithFormat:@"Average Heart Rate            :      %d BPM\nAverage Oxygen Saturation :      %.2f %%\n",avg_hr,avg_spo];

    UITextView *titleView = [[UITextView alloc]initWithFrame:CGRectMake(30, 90, self.view.width, 150)];
    
    //create attributed string and change font
    NSMutableAttributedString *summary = [[NSMutableAttributedString alloc]initWithString:text];
    UIFont* font = [UIFont fontWithName:@"HelveticaNeue-Ultralight" size:18];
    [summary addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, summary.length)];
    
    //assign text first, then customize properties
    titleView.attributedText = summary;
    titleView.textAlignment = NSTextAlignmentLeft;
    titleView.textColor = [UIColor darkTextColor];
    [self.view addSubview:titleView];
}

-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    if (DEBUG) {
        return true;
    }
    else{
        return false;
    }
}

-(void)bringFakeVC:(UIGestureRecognizer*)gr{
    [self performSegueWithIdentifier:@"fakeData" sender:self];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self refreshView];
    NSLog(@"viewWillAppear");
}

-(void)refreshView{
    NSArray *sortedHeartRateArray = [[FunkyHeartDataStore sharedStore]sortedHeartRateArray];
    NSArray *sortedOxygenSaturationArray = [[FunkyHeartDataStore sharedStore]sortedOxygenSaturationArray];
    
    NSMutableArray *heartRateValueArray = [[NSMutableArray alloc]init];
    for (FunkyHeartData *entry in sortedHeartRateArray) {
        if (entry.heartRate) {
            [heartRateValueArray addObject:entry.heartRate];
        }
    }
        
    NSMutableArray *oxygenSaturationValueArray = [[NSMutableArray alloc]init];
    for (FunkyHeartData *data in sortedOxygenSaturationArray) {
        if (data.oxygenSaturation) {
            [oxygenSaturationValueArray addObject:data.oxygenSaturation];
        }
    }

    graph2.values = heartRateValueArray;
    graph3.values = oxygenSaturationValueArray;
   // [self animate];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)animate
{
    [graph2 animate];
    [graph3 animate];
}

-(void)swipeDown:(UIGestureRecognizer *)gr{
}

@end
