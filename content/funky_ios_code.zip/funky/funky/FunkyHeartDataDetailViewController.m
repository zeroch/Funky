//
//  FunkyHeartDataDetailViewController.m
//  funky
//
//  Created by zchen78 on 2/15/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyHeartDataDetailViewController.h"
#import "FunkyHeartData.h"
#import "FunkyHeartDataStore.h"
@interface FunkyHeartDataDetailViewController ()

@property (weak, nonatomic) IBOutlet UILabel *oxygenSaturation;
@property (weak, nonatomic) IBOutlet UILabel *HeartRate;
@property (weak, nonatomic) IBOutlet UILabel *TimeStamp;

@end

@implementation FunkyHeartDataDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.oxygenSaturation.text = [self.entry.oxygenSaturation description];
    self.HeartRate.text = [self.entry.heartRate description];
    self.TimeStamp.text = [self.entry.timestamp description];

    
}

-(void)viewWillAppear:(BOOL)animated{
    self.oxygenSaturation.text = [self.entry.oxygenSaturation description];
    self.HeartRate.text = [self.entry.heartRate description];
    self.TimeStamp.text = [self.entry.timestamp description];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)clear:(id)sender {
    [[FunkyHeartDataStore sharedStore]clear];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
