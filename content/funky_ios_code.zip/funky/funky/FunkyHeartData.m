//
//  FunkyHeartData.m
//  funky
//  Basic Data Structure of HeartData.
//  oxygenSaturation(SPO2)
//  heartRate(heart rate /min)
//  timestamp;
//  Created by zchen78 on 2/13/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyHeartData.h"



@interface FunkyHeartData()

@end


@implementation FunkyHeartData

#pragma mark -init

+(instancetype)newRandomFunkyHeartData{
    //generate random oxygensaturation % from 75% to 100%;
    double oxygenSaturation = (drand48() *0.20 + 0.85);
    
    //generate random heart beat per miniute
    unsigned int heartRate = arc4random() % 70 + 50;
    //generate random date from now within 10 seconds.
    NSTimeInterval time = [NSDate timeIntervalSinceReferenceDate] +  (arc4random_uniform(10000));
    
    BOOL isOxygenSaturation = (heartRate>110)  ? FALSE:TRUE;
    
    FunkyHeartData *randomData = [[self alloc]initWithOxygenSaturation:oxygenSaturation heartRate:heartRate timeSinceReferenceDate:time isOxygenSaturation:isOxygenSaturation];
    return randomData;
}

-(instancetype)init{
    self = [super init];
    if (self) {
        _oxygenSaturation = nil;
        _heartRate = nil;
        _timestamp = nil;
    }
    return self;
}

-(instancetype)initWithOxygenSaturation:(float)oxygenSaturation
                                       heartRate:(unsigned int)heartRate
                                       timeSinceReferenceDate:(NSTimeInterval)timeSinceReferenceDate
                                        isOxygenSaturation:(BOOL)isOxygenSaturation
{
    self = [super init];
    if (self) {
        
        if (isOxygenSaturation) {
            _oxygenSaturation = [NSNumber numberWithFloat:oxygenSaturation];
            _heartRate = nil;
            _isOxygenSaturation = TRUE;
        }
        
        else{
            _heartRate = [NSNumber numberWithInt:heartRate];
            _oxygenSaturation = nil;
            _isOxygenSaturation = FALSE;
        }
        
        _timestamp = [NSDate dateWithTimeIntervalSinceReferenceDate:timeSinceReferenceDate];
    }
    return self;
}

#pragma mark - NSCoding protocol
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.oxygenSaturation forKey:@"oxygenSaturation"];
    [aCoder encodeObject:self.heartRate forKey:@"heartRate"];
    [aCoder encodeObject:self.timestamp forKey:@"timestamp"];
    [aCoder encodeBool:self.isOxygenSaturation forKey:@"isOxygenSaturation"];
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        _oxygenSaturation = [aDecoder decodeObjectForKey:@"oxygenSaturation"];
        _heartRate = [aDecoder decodeObjectForKey:@"heartRate"];
        _timestamp = [aDecoder decodeObjectForKey:@"timestamp"];
        _isOxygenSaturation = [aDecoder decodeBoolForKey:@"isOxygenSaturation"];
    }
    
    return self;
}

#pragma mark -NSObject
-(BOOL)isEqual:(id)object{
    if ([self class] == [object class]) {
        if ( _oxygenSaturation == [(FunkyHeartData *)object oxygenSaturation] && _heartRate == [(FunkyHeartData *)object heartRate] && _timestamp == [(FunkyHeartData*)object  timestamp] ) {
            return true;
        }
        return false;
    }
    return false;
}

-(NSString *)description{
    return [NSString stringWithFormat:@"SPO2:%@ HeartRate:%@ Time:%@",self.oxygenSaturation,self.heartRate,self.timestamp];
}
@end
