//
//  FunkyHeartDataTableViewController.m
//  funky
//
//  Created by zchen78 on 2/15/15.
//  Copyright (c) 2015 zchen78. All rights reserved.
//

#import "FunkyHeartDataTableViewController.h"
#import "FunkyHeartDataDetailViewController.h"
#import "FunkyHeartDataStore.h"
#import "FunkyHeartData.h"

@interface FunkyHeartDataTableViewController ()

@end

@implementation FunkyHeartDataTableViewController

-(instancetype)init{
    
    self = [super init];
    
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
    [self.tableView registerClass:[UITableViewCell class]
           forCellReuseIdentifier:@"UITableViewCell"];
    
    if ([HKHealthStore isHealthDataAvailable]) {
        NSSet *writeDataTypes = [self dataTypesToWrite];
        NSSet *readDataTypes = [self dataTypesToRead];
        
        [[[FunkyHeartDataStore sharedStore]healthStore]requestAuthorizationToShareTypes:writeDataTypes readTypes:readDataTypes completion:^(BOOL success,NSError *error){
            if (!success) {
                NSLog(@"You didn't allow HealthKit to access these read/write data types. In your app, try to handle this error gracefully when a user decides not to provide access. The error was: %@. If you're using a simulator, try it on a device.", error);
                return;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                // Update the user interface based on the current user's health information.
                //Here can be used if need to used the read data
            });
        }];
    }
    
    self.tableView.scrollsToTop = YES;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [[[FunkyHeartDataStore sharedStore]allData]count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    
    NSArray *items = [[FunkyHeartDataStore sharedStore]allData];
    FunkyHeartData *entry = items[indexPath.row];
    
    cell.textLabel.text = [entry description];
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
        NSArray *items = [[FunkyHeartDataStore sharedStore]allData];
        FunkyHeartData *entry = items[indexPath.row];
        [[FunkyHeartDataStore sharedStore]removeFunkyHeartDataEntry:entry];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}



// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
    [[FunkyHeartDataStore sharedStore]moveItemAtIndex:fromIndexPath.row toIndex:toIndexPath.row];
}


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    //ShowFunkyDetailView
    
    NSIndexPath *selectedPath = [self.tableView indexPathForSelectedRow];

    NSArray *items = [[FunkyHeartDataStore sharedStore]allData];
    
    FunkyHeartData *dataEntry = items[selectedPath.row];
    
    FunkyHeartDataDetailViewController *detailVC = segue.destinationViewController;

    detailVC.entry = dataEntry;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [self performSegueWithIdentifier:@"ShowFunkyDetailView" sender:self];

}



- (IBAction)addEntry:(id)sender {
    FunkyHeartData *newEntry = [FunkyHeartData newRandomFunkyHeartData];
    
    [[FunkyHeartDataStore sharedStore]addFunkyHeartDataEntry:newEntry];
    [self.tableView reloadData];
}

#pragma mark -HealthKit request permission 

//Write Heart Rate
//Write OxygenSaturation
-(NSSet *)dataTypesToWrite {
    HKQuantityType *HeartRateType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeartRate];
    HKQuantityType *oxygenSaturationType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierOxygenSaturation];
    return [NSSet setWithObjects:HeartRateType,oxygenSaturationType, nil];
}

//Read Data

-(NSSet *)dataTypesToRead{
    HKQuantityType *heightType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeight];
    HKQuantityType *weightType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass];
    HKQuantityType *stepCountType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    HKQuantityType *distanceWalkingRunningType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning];
    HKQuantityType *flightsClimbedType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed];
    HKCharacteristicType *birthdayType = [HKObjectType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierDateOfBirth];
    HKCharacteristicType *biologicalSexType = [HKObjectType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierBiologicalSex];
    return [NSSet setWithObjects:heightType,weightType,stepCountType,distanceWalkingRunningType,flightsClimbedType,birthdayType,biologicalSexType, nil];
}

-(bool)scrollViewShouldScrollToTop:(UIScrollView *)scrollView{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    return NO;
    
}


@end
